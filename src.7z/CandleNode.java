public class CandleNode
{
	protected Candle candle;
	protected CandleNode next;

	public CandleNode(Candle c)
	{
		candle = c;
		next = null;
	} // constructor
} // class ShortNode
