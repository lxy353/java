
public class UnsortedCandleList extends CandleList
{
	public UnsortedCandleList()
	{
		super();
	}

	public void add(Candle c)
	{
		append(c);
	}
}
