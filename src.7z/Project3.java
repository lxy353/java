import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Project3
{
	public static void main(String[] args) throws FileNotFoundException
	{
		CandleGUI gui = new CandleGUI();
		gui.show();
	}
}